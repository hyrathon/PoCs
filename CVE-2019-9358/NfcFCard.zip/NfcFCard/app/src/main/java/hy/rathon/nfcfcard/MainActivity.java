package hy.rathon.nfcfcard;

import android.content.ComponentName;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.nfc.NfcAdapter;
import android.nfc.cardemulation.NfcFCardEmulation;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class MainActivity extends AppCompatActivity {
    NfcAdapter nfcAdapter;
    NfcFCardEmulation nfcFCardEmulation;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        nfcAdapter = NfcAdapter.getDefaultAdapter(this);
        nfcFCardEmulation = NfcFCardEmulation.getInstance(nfcAdapter);
    }

    @Override
    protected void onPause() {
        super.onPause();
        nfcFCardEmulation.disableService(this);

    }

    @Override
    protected void onResume() {
        super.onResume();
        ComponentName serviceName = new ComponentName(getPackageName(), MyHostNfcFService.class.getName());
        nfcFCardEmulation.enableService(this, serviceName);
    }
}
