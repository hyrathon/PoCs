package hy.rathon.nfcfcard;

import android.nfc.cardemulation.HostNfcFService;
import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;

public class MyHostNfcFService extends HostNfcFService {
    public MyHostNfcFService() {
    }


    @Override
    public byte[] processNfcFPacket(byte[] commandPacket, Bundle extras) {
        Log.d("NfcFCard", new String(commandPacket));
        return commandPacket;
    }

    @Override
    public void onDeactivated(int reason) {
        Toast.makeText(this, "Link breaks", Toast.LENGTH_SHORT).show();
    }

}
