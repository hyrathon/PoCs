package hy.rathon.nfcfreader;

import android.nfc.NfcAdapter;
import android.nfc.Tag;
import android.nfc.tech.NfcF;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;

import java.io.IOException;

public class MainActivity extends AppCompatActivity implements NfcAdapter.ReaderCallback {

    final int FLAG = NfcAdapter.FLAG_READER_NFC_F | NfcAdapter.FLAG_READER_NO_PLATFORM_SOUNDS;
    private NfcAdapter mNfcAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mNfcAdapter = NfcAdapter.getDefaultAdapter(this);
    }

    @Override
    protected void onPause() {
        super.onPause();
        mNfcAdapter.disableReaderMode(this);
    }

    @Override
    protected void onResume() {
        super.onResume();
        mNfcAdapter.enableReaderMode(this, this, FLAG, null);
    }

    byte[] rawCmd(NfcF nfcF, byte felicaCmd, byte[] IDm, byte[] payload) throws IOException {
        final int len = payload != null ? payload.length : 0;

        final byte[] cmd = new byte[10 + len];
        cmd[0] = (byte) (10 + len);
        cmd[1] = felicaCmd;
        System.arraycopy(IDm, 0, cmd, 2, IDm.length);

        if (payload != null) {
            System.arraycopy(payload, 0, cmd, 10, payload.length);
        }

        return nfcF.transceive(cmd);
    }

    @Override
    public void onTagDiscovered(Tag tag) {
        NfcF f = NfcF.get(tag);
        try {
            f.connect(); // This is necessary for nfc state can be changed at any time
            if(f.isConnected()){
                byte[] IDm = {0x02, (byte)0xfe, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00};
                byte[] payload = {
                        0x14, //num_services, with a maxium of 16
                        0x66, 0x66, 0x66, 0x66, 0x66, 0x66, 0x66, 0x66,
                        0x66, 0x66, 0x66, 0x66, 0x66, 0x66, 0x66, 0x66,
                        0x66, 0x66, 0x66, 0x66, 0x66, 0x66, 0x66, 0x66,
                        0x66, 0x66, 0x66, 0x66, 0x66, 0x66, 0x66, 0x66, // 16-bit service numbers

                        (byte)0xef, (byte)0xbe, (byte)0xad, (byte)0xde, // overflow
                        (byte)0xef, (byte)0xbe, (byte)0xad, (byte)0xde,


                        0x66, 0x66, 0x66, 0x66, 0x66, 0x66, 0x66, 0x66,
                        0x66, 0x66, 0x66, 0x66, 0x66, 0x66, 0x66, 0x66,
                        0x66, 0x66, 0x66, 0x66, 0x66, 0x66, 0x66, 0x66,
                        0x66, 0x66, 0x66, 0x66, 0x66, 0x66, 0x66, 0x66, //paddings

                };
                byte felicaCmd = 0x06;
                byte[] response = rawCmd(f, felicaCmd, IDm, payload);

            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
